import React, { useState } from 'react'

export default () => {
  const [toggleableThing, setToggleableThing] = useState(true)
  const buttonCls = toggleableThing ? 'btn btn--green' : 'btn btn--danger'

  return <button className={buttonCls} onClick={() => setToggleableThing(!toggleableThing)}>
    {toggleableThing ? 'Green' : 'Red'}
  </button>
}