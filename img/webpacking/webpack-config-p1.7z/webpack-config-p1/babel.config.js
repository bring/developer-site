module.exports = function (api) {
  api.cache(true)

  return {
    presets: [
      [
        '@babel/preset-env',
        {
          targets: '> .2%, ie 11',
        },
      ],
      '@babel/react',
    ],
  }
}
