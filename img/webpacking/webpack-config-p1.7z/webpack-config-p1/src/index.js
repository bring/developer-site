import React from 'react'
import { render } from 'react-dom'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import { Redirect } from 'react-router'
import WebpackInfo from './components/WebpackInfo'
import OtherInfo from './components/OtherInfo'

render(
    <BrowserRouter>
      <Switch>
        <Route exact path="/">
          <WebpackInfo/>
        </Route>
        <Route exact path="/other">
          <OtherInfo/>
        </Route>
        <Redirect to="/"/>
      </Switch>
    </BrowserRouter>,
    document.querySelector('#main')
)
