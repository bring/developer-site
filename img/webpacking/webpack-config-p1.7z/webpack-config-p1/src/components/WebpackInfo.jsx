import React from 'react'
import { Link } from 'react-router-dom'
import ButtonWithColorToggle from './ButtonWithColorToggle'

export default () => {
  return <>
    <h2>Webpack</h2>
    <p>
      Bundles your files and dependencies using your config. Outputs files
      that the browser can read.
    </p>
    <p>
      <Link to="/other">What about other bundlers?</Link>
    </p>
    <p>
      <ButtonWithColorToggle/>
    </p>
  </>
}
