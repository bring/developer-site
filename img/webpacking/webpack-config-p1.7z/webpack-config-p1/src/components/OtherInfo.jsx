import React from 'react'
import { Link } from 'react-router-dom'

export default () => {
  return <>
    <h2>Other bundlers</h2>
    <p>
      Learning how to configure one bundler means you can reuse some of the
      concepts in other tools like Rollup, Parcel, Grunt and Gulp.
    </p>
    <p>
      <Link to="/">Webpack?</Link>
    </p>
  </>
}
