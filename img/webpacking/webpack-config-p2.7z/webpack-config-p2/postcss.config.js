module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-css-variables': {},
    autoprefixer: {},
    cssnano: {},
  },
}
