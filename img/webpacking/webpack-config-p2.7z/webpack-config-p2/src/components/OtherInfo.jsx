import React from 'react'
import { Link } from 'react-router-dom'
import css from './OtherInfo.css'

export default () => {
  return (
    <>
      <h2>Other bundlers</h2>
      <p>
        Learning how to configure one bundler means you can reuse some of the
        concepts in other tools like Rollup, Parcel, Grunt and Gulp.
      </p>
      <div className={`${css.parcelInfo} mb5r`}>
        There’s a parcel somewhere
      </div>
      <p>
        <Link to="/">Webpack?</Link>
      </p>
    </>
  )
}
